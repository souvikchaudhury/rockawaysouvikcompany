$(document).ready(function() {
	
	$('.captcha_refresh').click(function(e){
		e.preventDefault();
		var gettt = $(this).parent().parent().attr("class");
		rannocaptch = random_number();
		$('.'+gettt).find('.captcha_code_i').text(rannocaptch);
		$('.'+gettt).find('.captcha_orig').val(rannocaptch);
	});
	
	
	var myInput = document.getElementById("captcha-textfield");
		myInput.onpaste = function(e) {
				e.preventDefault();
   };
   $('.generateranno').each(function(){
		$(this).click(function(){
			getId =$(this).attr('href');
		});
	});
	$('.book-now').fancybox({
		onCancel	:	function() {
			//alert(getId);
			$(getId).find('form')[0].reset();
		}
	});
	//$('.reservation_no').val($('.reservation_no_option').val());
	$('.generateranno').click(function(){
		//var rnno = Math.floor((Math.random()*100000000)+100);
		/*var rnno = parseInt($('.reservation_no').val())+1;
		$('.reservation').empty();
		$('.reservation').append(rnno);	
		$('.reservation_no').val(rnno);*/
                $('.errormsgdisp').empty();
                $('.errormsgdisp').fadeOut();
		rannocaptch = random_number();
		$('.captcha_code_i').text(rannocaptch);
		$('.captcha_orig').val(rannocaptch);
	});	
	$('.text').attr('disabled','disabled');	
	$('body').on('click','.checkbox',function(){
		//document.getElementById($(this).siblings('.text').attr("id")).readOnly = false;
		
		var getId = $(this).siblings('.text').attr("id");
		var $getClass = $(this).parent().parent().attr("class");
		
		$('#'+getId).toggleClass('disT');

		//alert($('.disT').val());
		
		if($('#'+getId).hasClass('disT')){
			$('#'+getId).removeAttr('disabled');
			}
		else{
			$('#'+getId).attr('disabled','disabled');
			$('#'+getId).val('');
			}
		totalvaluecalc($getClass);
	});
	rt = 0;
	$('.text').keyup(function () { 
		
	    this.value = this.value.replace(/[^0-9\.]/g,'');
		//getNo = parseInt(this.value);
		$getClass = $(this).parent().parent().attr("class");
		totalvaluecalc($getClass);
	});

	$('.getdistancesubmit').click(function(){
		if($('.googlemapform .address_input').val()!='')
		{
			var destinationaddr = $('.googlemapform .address_input1').val();
			var sourceaddr = $('.googlemapform .address_input').val();
			var url = "https://maps.google.com/maps?saddr="+sourceaddr+"&daddr="+destinationaddr;
            window.open(url, '_blank');
		}
		
	});


});
function random_number()
{
	var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}
function totalvaluecalc($getClas)
{
	rt = 0;
	ticketcost = 0;
	
	getLength = $('.'+$getClas).find('.disT').length;
	if(getLength!=0){
	$('.'+$getClas).find('.disT').each(function(){
		textval = isNaN(parseInt($(this).val())) ? 0 : parseInt($(this).val());
		ticketval = isNaN(parseInt($(this).val())) ? 0 : parseInt($(this).val());
		
		if($(this).hasClass('ad'))
		{
			adultprice = $('.'+$getClas).find('.adult_price').val();
			ticketval = ticketval * adultprice;	
		}
		if($(this).hasClass('sn'))
		{
			seniorprice = $('.'+$getClas).find('.senior_price').val();
			ticketval = ticketval * seniorprice;	
		}
		if($(this).hasClass('ch'))
		{
			childrenprice = $('.'+$getClas).find('.children_price').val();
			ticketval = ticketval * childrenprice;	
		}
		rt = rt + textval; 
		ticketcost = ticketcost + ticketval;
		
		$('.total-ticket_no').empty();
		$('.total-ticket_no').text(rt);
		$('.total-ticket_no_text').val(rt);
		$('.total-ticket_cost').empty();
		$('.total-ticket_cost').text('$'+ticketcost);
		$('.total-ticket_cost_text').val(ticketcost);	
	});
	}
	else{
		$('.total-ticket_no').empty();
		$('.total-ticket_no').text(0);
		$('.total-ticket_cost').empty();
		$('.total-ticket_cost').text('$0');
		$('.total-ticket_no_text').val(0);
		}
	
}
function chkForm(f)
{
	valid=true;
        var err = [];
	counter=0;
	firstname = document.forms[f.name]['firstname'].value;
	if(firstname=='Enter Your First Name' || firstname == '' || firstname == null)
	{
		err.push( "**Please Provide Your Firstname<br>" );
//		return false;
		counter = 1;
		valid=false;
	}
	
	var lastname = document.forms[f.name]['lastname'].value;
	if(lastname=='Enter Your Last Name' || lastname == '' || lastname == null)
	{
                err.push( "**Please Provide Your Lastname<br>" );
		counter = 1;
		valid=false;
//                alert('Please Provide Your Lastname');
//		return false;
	}
	var email = document.forms[f.name]['email'];
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
	if (!email.value.match(mailformat)) 
	{
            err.push( "**Please Provide Your Correct Email ID <br>" );
            counter = 1;
            valid=false;
//            alert('Please Provide Your email');
//            return false;
	}
	var mobile_number = document.forms[f.name]['phone'].value;
//	if (mobile_number == '' || mobile_number == null || isNaN(mobile_number) || mobile_number =="Enter Your Phone No" || mobile_number.length<10)
	if (mobile_number == '' || mobile_number == null || mobile_number =="Enter Your Phone No")
	{
        err.push( "**Please Provide Your Correct Mobile No. <br>" );
		counter = 1;
		valid=false;
//                alert('Please Provide Your mobile');
//		return false;
	}
        total_ticket_cost_text = document.forms[f.name]['total-ticket_cost_text'].value;
	total_ticket_no_text = document.forms[f.name]['total-ticket_no_text'].value;
	
	if(total_ticket_cost_text==null || total_ticket_cost_text=='' || total_ticket_no_text==null || total_ticket_no_text=='')
	{
            err.push( "**Please Provide Total No. of Ticket Division <br>" );
		counter = 1;
		valid=false;
//                alert('Please Provide Your total cost');
//		return false;
	}
	season_pass = $('input[name=season-pass]:checked').val();
	if(season_pass==null || season_pass=="")
	{
            err.push( "**Please Provide Season Pass Information. <br>" );
		counter = 1;
		valid=false;
//                alert('Please Provide Your season pass');
//		return false;
	}
//	purchase = $('input[name=purchase]:checked').val();
//	if(purchase==null || purchase=="")
//	{
//		counter = 1;
//		valid=false;
//	}
	seating = $('input[name=seating]:checked').val();
	if(seating==null || seating=="")
	{
             err.push( "**Please Provide Wheelchair Access & seating required Information. <br>" );
		counter = 1;
		valid=false;
//                alert('Please Provide Your seating');
//		return false;
	}
	
	
	var captcha_text = document.forms[f.name]['captcha-textfield'].value;
	if(captcha_text==null || captcha_text=='')
	{
            err.push( "**Please Provide Captcha<br>" );
		counter = 1;
		valid=false;
//                alert('Please Provide Your Captcha');
//		return false;
	}
	if(counter==1)
	{
                $('form[name='+f.name+']').find('.errormsgdisp').empty();
		$('form[name='+f.name+']').find('.errormsgdisp').append(err).slideDown("fast");
		valid=false;
	}
	else
	{
		captchaval = $('form[name='+f.name+']').find('.captcha_orig').val();
		captchawritten = $('form[name='+f.name+']').find('.captcha-textfield').val();
		
		if(captchaval.toLowerCase() == captchawritten.toLowerCase())
		{
			valid=true;
		}
		else
		{
			rannocaptch = random_number();
			$('form[name='+f.name+']').find('.captcha_code_i').empty();
			$('form[name='+f.name+']').find('.captcha_code_i').text(rannocaptch); //span
			$('form[name='+f.name+']').find('.captcha_orig').val(rannocaptch);  //hidden field
			$('form[name='+f.name+']').find('.captcha-textfield').val(''); //wriiten field clear
                        
			$('form[name='+f.name+']').find('.errormsgdisp').empty();
                        $('form[name='+f.name+']').find('.errormsgdisp').fadeOut();
			$('form[name='+f.name+']').find('.captchaerrormsg').slideDown("fast");
			valid=false;
		}
		//if($('.captcha_orig').val()==
	}
	return valid;
}

