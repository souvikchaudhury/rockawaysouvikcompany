<?php
/*
Template Name: Ticket Reservation
*/

if(get_option('reservation_no_generate')==false)
{
	add_option( 'reservation_no_generate', '10000');
}

function set_html_content_type() {

	return 'text/html';
}
if(isset($_POST['submit']))
{
	$table = 'wp_ticketreservation';
	
	$part_number['adult']=($_POST['adult']!='' ? $_POST['adult'] : 0);
	$part_number['adult_price']=$_POST['adult_price'];
	$part_number['senior']=($_POST['senior']!='' ? $_POST['senior'] : 0);
	$part_number['senior_price']=$_POST['senior_price'];
	$part_number['child']=($_POST['child']!='' ? $_POST['child'] : 0);
	$part_number['child_price']=$_POST['children_price'];
	
	$arr['eventid']			      = $_POST['nwpostid'];
	$arr['eventtitle']		      = $_POST['nwposttitle'];
	$arr['eventdate']		      = $_POST['nwdate'];
	$arr['eventtime']			  = $_POST['nwtime'];
	$arr['firstname']			  = $_POST['firstname'];
	$arr['lastname']			  = $_POST['lastname'];
	$arr['email'] 				  = $_POST['email'];
	$arr['phone'] 			      = $_POST['phone'];
	$arr['total-ticket_no_text']  = $_POST['total-ticket_no_text'];
	$arr['total-ticket_cost_text']= $_POST['total-ticket_cost_text'];
	$arr['ticket_division']		  =	$part_number;
	$arr['season-pass']  		  = $_POST['season-pass'];
	$arr['purchase'] 			  = $_POST['purchase'];
	$arr['seating']  			  = $_POST['seating'];
	
	$valuearr = serialize($arr);
	
	$data = array( 
					'ticketregno' => $_POST['reservation_no'], 
					'reservationinfo' => $valuearr 
				 );
	
	$format = array(
						'%d',
						'%s'
					);
	$wpdb->insert( $table, $data, $format );
	//$to = get_option( 'admin_email' );
	//$to = 'patrick.meyers@dundeebrookit.com';
	//$to = 'Tickets@rockawaytheatrecompany.org';
	$to = get_option( 'ticketemailid',true);
	//$to = 'abhijit.cn@gmail.com';
	//$from = '[your-name] <[your-email]>';
	$subject = 'Ticket Reservation Information';
	$subject1 = $_POST['nwposttitle'].':Ticket Reservation';
	//$headers = 'From: "'.$_POST['firstname'].'"'.$_POST['email'];
	//$headers = 'From: '.$_POST['firstname'].'<'.$_POST['email'].'>' . "\r\n";
	$headers = 'From: Rockaway Theatre Company <'.$_POST['email'].'>' . "\r\n";
	$headers1 = 'From: Rockaway Theatre Company <'.$to.'>'. "\r\n";
	
	$message = '<table width="100%" border="0" cellspacing="0" cellpadding="0">
				  <tr>
				    <td width="20%">Show Name</td>
				    <td width="5%">:</td>
				    <td>'.$_POST['nwposttitle'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">Date</td>
				    <td width="5%">:</td>
				    <td>'.$_POST['nwdate'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">Time</td>
				    <td width="5%">:</td>
				    <td>'.$_POST['nwtime'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">Registration No</td>
				    <td width="5%">:</td>
				    <td>'.$_POST['reservation_no'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">Name</td>
				    <td width="5%">:</td>
				    <td>'.$_POST['firstname'].' '.$_POST['lastname'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">Email</td>
				    <td width="5%">:</td>
				    <td>'.$_POST['email'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">Phone</td>
				    <td width="5%">:</td>
				    <td>'.$_POST['phone'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">No. of Tickets</td>
				    <td width="5%">:</td>
				    <td>Adult- '.$part_number['adult'].', child- '.$part_number['senior'].', senior- '.$part_number['child'].'</td>
				  </tr>
				  <tr>
				    <td width="20%">Total Costs</td>
				    <td width="5%">:</td>
				    <td>$'.$_POST['total-ticket_cost_text'].'</td>
				  </tr>
				</table>';

	$message1 = '<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td>
						<img src="'.get_template_directory_uri().'/images/logo.png" alt="" width="147" height="128" />
					</td>
				</tr>
				<tr>
				<td>
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
					  <tr>
					    <td width="20%">Show Name</td>
					    <td width="5%">:</td>
					    <td>'.$_POST['nwposttitle'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">Date</td>
					    <td width="5%">:</td>
					    <td>'.$_POST['nwdate'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">Time</td>
					    <td width="5%">:</td>
					    <td>'.$_POST['nwtime'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">Registration No</td>
					    <td width="5%">:</td>
					    <td>'.$_POST['reservation_no'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">Name</td>
					    <td width="5%">:</td>
					    <td>'.$_POST['firstname'].' '.$_POST['lastname'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">Email</td>
					    <td width="5%">:</td>
					    <td>'.$_POST['email'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">Phone</td>
					    <td width="5%">:</td>
					    <td>'.$_POST['phone'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">No. of Tickets</td>
					    <td width="5%">:</td>
					    <td>Adult- '.$part_number['adult'].', child- '.$part_number['senior'].', senior- '.$part_number['child'].'</td>
					  </tr>
					  <tr>
					    <td width="20%">Total Costs</td>
					    <td width="5%">:</td>
					    <td>$'.$_POST['total-ticket_cost_text'].'</td>
					  </tr>
					</table>
					</td>
					</tr></table>';
	
	add_filter( 'wp_mail_content_type', 'set_html_content_type' );
	wp_mail( $to, $subject, $message,$headers );
	wp_mail( $_POST['email'], $subject1, $message1,$headers1 );
	remove_filter( 'wp_mail_content_type', 'set_html_content_type' );	
}
function gettimeinfo($date1,$date2,$getpostid,$count,$seatavlstat)
{
	if($date1 < $date2)
    	{
            $diff = $date2->diff($date1);
            $hours = $diff->h;
            $hours = $hours + ($diff->d*24);
            if($hours<=24)
                {
                   $ticket_info_type = '<span class="sold-out phoneorder">Phone Order/Walk-In Only *</span><br>';
                   $timeupclass = '';
                   $timeupmessage = '<div class="nb-section">* We still have tickets available, but you can only reserve by phone or by coming directly to the theatre for this performance. *</div>';
                }
            else
                {
                    $ticket_info_type = ($seatavlstat=='Yes'?('<span class="available">SEATS AVAILABLE</span><a class="book-now generateranno" href="#booknow-form'.$getpostid.$count.'">BOOK NOW</a>'):'<span class="sold-out">Sold out</span>').'<br>';
                    $timeupclass = '';
                }
          $statuscounter = 'hasconcert';
        }
    else
        {
    	   	$ticket_info_type = '<span class="sold-out">Sold Out</span><br>';
    	   	$timeupclass = 'timeup';
        }
   return array($ticket_info_type,$timeupclass,$statuscounter);
}
?>
<?php get_header(); ?>


<?php 
			$args = array(
							'posts_per_page'   => -1,
							'orderby'          => 'post_date',
							'order'            => 'desc',
							'post_type'        => 'events_booking',
							'post_status'      => 'publish'
						 ); 
			$posts_array = get_posts( $args );
?> 
        	<div id="ticket_inner">
        <div class="ticket_area_inner">
            <h1>Ticket Reservation Area</h1>
            <h2>Upcoming Events<span></span></h2>
<?php 
function change_post_status($post_id,$status){
    $current_post = get_post( $post_id, 'ARRAY_A' );
    $current_post['post_status'] = $status;
    wp_update_post($current_post);
}
			foreach ($posts_array as $posts)
			{
?>
           	<!--event start-->
            <div class="event-total-part">
            	<div class="event-inner">
                	<div class="event-top-text">
                    	<img src="<?php echo get_bloginfo("template_url")."/images/"; ?>ticket-img1.gif" alt="" />
                        <span>Rockaway Theatre Company in partnership with
Gateway National Recreation Area proudly presents:</span>
                        <img src="<?php echo get_bloginfo("template_url")."/images/"; ?>ticket-img2.gif" alt="" />
                    </div>
                    
                    <div class="event-detail">
                    	<h3><?php echo $posts->post_title;?></h3>
                       
                        <?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($posts->ID)); ?>
                        <img alt="" src="<?php echo $large_image_url[0]; ?>" style="width:159px; height: 159px;"> 
                        <?php $directed = get_post_meta( $posts->ID, '_directed', true ); 
                        if ($directed)
                        {
                        ?>
                        <p>Directed By : 
                            <span><?php echo $directed; ?></span>
                        </p>
                        <?php 
                        }
                        $musicdirection = get_post_meta( $posts->ID, '_musicdirection', true );
                        if ($musicdirection)
                        {
                        ?>
                        <p>
                        	 Musical Direction By : 
                            <span><?php echo $musicdirection; ?></span>
                        </p>
                        <?php 
                        }
                        $musicarrangement = get_post_meta( $posts->ID, '_musicarrangement', true );
                        if ($musicarrangement)
                        {
                        ?>
                        <p>
                        	Musical Arrangements By : 
                            <span><?php echo $musicarrangement; ?></span>
                        </p>
                        <?php 
                        }
                        $written = get_post_meta( $posts->ID, '_written', true );
                        if ($written)
                        {
                        ?>
                        <p>
                        	Musical Arrangements By : 
                            <span><?php echo $written; ?></span>
                        </p>
                        <?php 
                        }
                        $venue = get_post_meta( $posts->ID, '_venue', true );
                        if ($venue)
                        {
                        ?>
                        		<h4><?php echo $venue; ?></h4> 
                        <?php 
                         }
                         echo apply_filters('the_content',$posts->post_content);
						?>
                   
                    </div>
                    
                    <div class="ticket-status-top"></div>
	                    <div class="ticket-status-main">
	                    	<h3>Ticket Information : </h3>
	                    	<table>
	                    		<tr>
	                    			<td>Adults</td>
	                    			<td>:</td>
	                    			<td>$<?php echo ($musicalinfo=='Musical'? get_option( 'adults_musical',true):get_option( 'adults_nonmusical',true));?></td>
	                    		</tr>
	                    		<tr>
	                    			<td>Seniors</td>
	                    			<td>:</td>
	                    			<td>$<?php echo ($musicalinfo=='Musical'? get_option( 'seniors_musical',true):get_option( 'seniors_nonmusical',true));?></td>
	                    		</tr>
	                    		<tr>
	                    			<td>Childrens</td>
	                    			<td>:</td>
	                    			<td>$<?php echo ($musicalinfo=='Musical'? get_option( 'children_musical',true):get_option( 'children_nonmusical',true));?></td>
	                    		</tr>
	                    	</table>
	                    	<h3>PERFORMANCE SCHEDULE :</h3>
	                    	<?php 
	                    	$total_no_eventperformance = get_post_meta( $posts->ID, '_total_no_eventperformance', true );
							$eventperformance_schedule = get_post_meta( $posts->ID, '_eventperformance_schedule', true );
							$musicalinfo = get_post_meta( $posts->ID, '_musicalinfo', true );
							$reason_contents = unserialize($eventperformance_schedule);
			  				$count=1;
			  				foreach ($reason_contents as $reason_content)
			  				{
			  					$reservation_ticket_no = get_option( 'reservation_no_generate');
			  					
			  					$originalDate = $reason_content['eventperformancedate'];
			  					$newDate = date("M d,Y", strtotime($originalDate));
			  					
			  					$originalTime = $reason_content['eventperformancetime'];
			  					$time_in_12_hour_format  = date("g:i a", strtotime($originalTime));
			  					
			  					$get_date_time_event = date("Y-m-d", strtotime($originalDate)).T.$originalTime;
                 				$date1 = new DateTime("now");
                                $date2 = new DateTime($get_date_time_event);
                                if($date1 < $date2)
    							{
    								$statusofdate="hasconcert";
    							}
                  				//var_dump($date1);
                                     /*$diff=$date2->diff($date1);
									 print_r( $diff ) ;*/
								$getinformation = gettimeinfo($date1,$date2,$posts->ID,$count,$reason_content['seatavailability']);
                                ?>
                                
                                <div class="ticket-line <?php echo $getinformation[1]; ?>">
				  					<div class="date"><?php echo $newDate; ?></div>
				  					<div class="time"><?php echo $time_in_12_hour_format; ?></div>
                                     <?php echo $getinformation[0]; ?>
					                            <div id="booknow-form<?php echo $posts->ID.$count;?>" class="popup" style="display: none;">
						                                <h2>Online Booking Form</h2>
						                                <div class="popup-main">
						                                    <div class="ticket-show-img">
						                                    
						                                        <img alt="" src="<?php echo $large_image_url[0]; ?>" style="width:159px; height: 159px;"> 
						                                    </div>
						                                     <form name="booknow-form<?php echo $posts->ID.$count;?>"  method="post" onSubmit='return chkForm(this)' action="">
						                                     <input type="hidden" value="<?php echo $posts->ID; ?>" name="nwpostid" />    
						                                    <div class="show-confirmation">
						                                        <p>Name of Show : 		
						                                        	<span>
						                                        		<?php echo $posts->post_title;?>
						                                        		<input type="hidden" value="<?php echo $posts->post_title; ?>" name="nwposttitle" />    
						                                        	</span>
						                                        </p>
						                                        <p>Date : 				
						                                        	<span>
						                                        		<?php echo $newDate; ?>
						                                        		<input type="hidden" value="<?php echo $newDate; ?>" name="nwdate" />
						                                        	</span>
						                                        </p>
						                                        <p>Time : 				
						                                        	<span>
						                                        		<?php echo $time_in_12_hour_format; ?>
						                                        		<input type="hidden" value="<?php echo $time_in_12_hour_format; ?>" name="nwtime" />
						                                        	</span>
						                                        </p>
						                                        <p>Reservation Number : <span class="reservation"><?php echo $reservation_ticket_no; ?></span></p>
						                                        <input type="hidden" name="reservation_no" id="reservation_no" class="reservation_no" value="<?php echo $reservation_ticket_no; ?>">
						                                    
						                                    </div>
						                                    <!--ticket booking form start-->
						                                    <div class="ticket-booking-form chk<?php echo $posts->ID.$count?>">
						                                    
						                                        <div class="text-div">
						                                            <label>First Name</label>
						                                            <input type="text" name="firstname" value="Enter Your First Name" onfocus="if(this.value=='Enter Your First Name') this.value=''" onblur="if(this.value=='') this.value='Enter Your First Name'" />
						                                        </div>
						                                        <div class="text-div-right">
						                                            <label>Last Name</label>
						                                            <input type="text" name="lastname" value="Enter Your Last Name" onfocus="if(this.value=='Enter Your Last Name') this.value=''" onblur="if(this.value=='') this.value='Enter Your Last Name'" />
						                                        </div>
						                                      <div class="text-div">
						                                            <label>Email Address</label>
						                                            <input type="text" name="email" value="Enter Your Email Address" onfocus="if(this.value=='Enter Your Email Address') this.value=''" onblur="if(this.value=='') this.value='Enter Your Email Address'" />
						                                        </div>
						                                        <div class="text-div-right">
						                                            <label>Phone No</label>
						                                            <input type="text" name="phone" value="Enter Your Phone No" onfocus="if(this.value=='Enter Your Phone No') this.value=''" onblur="if(this.value=='') this.value='Enter Your Phone No'" />
						                                        </div>
						                                        <div class="text<?php echo $posts->ID.$count?>">
							                                        <div class="age-status">
							                                            <input type="checkbox" value="adult" class="styled adult_chk<?php echo $posts->ID.$count?>" name="adult_chk<?php echo $posts->ID.$count?>" id="adult_chk<?php echo $posts->ID.$count?>"/>
							                                            <span class='age-status-result'>Adult</span>
							                                            <input type="text" name="adult" class="ad text adult_txt<?php echo $posts->ID.$count?>" name="adult_txt<?php echo $posts->ID.$count?>" id="adult_txt<?php echo $posts->ID.$count?>" />
							                                            <input type="hidden" name="adult_price" value="<?php echo ($musicalinfo=='Musical'? get_option( 'adults_musical',true):get_option( 'adults_nonmusical',true));?>" class="adult_price" id="adult_price<?php echo $posts->ID.$count?>" style="width: 50px;"/>
							                                        </div>
							                                        <div class="age-status">
							                                            <input type="checkbox" value="senior" class="styled senior_chk<?php echo $posts->ID.$count?>" name="senior_chk<?php echo $posts->ID.$count?>" id="senior_chk<?php echo $posts->ID.$count?>"/>
							                                            <span class='age-status-result'>Senior</span>
							                                            <input type="text" name="senior" class="sn text senior_txt<?php echo $posts->ID.$count?>" name="senior_txt<?php echo $posts->ID.$count?>" id="senior_txt<?php echo $posts->ID.$count?>" />
							                                            <input type="hidden" name="senior_price" value="<?php echo ($musicalinfo=='Musical'? get_option( 'seniors_musical',true):get_option( 'seniors_nonmusical',true));?>" class="senior_price" id="senior_price<?php echo $posts->ID.$count?>" style="width: 50px;"/>
							                                        </div>
							                                        <div class="age-status">
							                                            <input type="checkbox" value="child" class="styled child_chk<?php echo $posts->ID.$count?>" name="child_chk<?php echo $posts->ID.$count?>" id="child_chk<?php echo $posts->ID.$count?>"/>
							                                            <span class='age-status-result'>Child</span>
							                                            <input type="text" name="child" class="ch text child_txt<?php echo $posts->ID.$count?>" name="child_txt<?php echo $posts->ID.$count?>" id="child_txt<?php echo $posts->ID.$count?>" />
							                                            <input type="hidden" name="children_price" value="<?php echo ($musicalinfo=='Musical'? get_option( 'children_musical',true):get_option( 'children_nonmusical',true));?>" class="children_price" id="children_price<?php echo $posts->ID.$count?>" style="width: 50px;"/>
							                                        </div> 
							                                        <div class="total-cost">
							                                            Total Cost :  <span class="total-ticket_cost">$0</span>
							                                            <input type="hidden" name="total-ticket_cost_text" id="total-ticket_cost_text" class="total-ticket_cost_text"/>
							                                        </div>
							                                        
							                                        <div class="total-ticket">Total Number of Tickets : <span class="total-ticket_no">0</span>
							                                        	<input type="hidden" name="total-ticket_no_text" id="total-ticket_no_text" class="total-ticket_no_text"/>
							                                        </div>
						                                        </div>
						                                        <div class="radio-div">
						                                            <label>Will this reservation be applied against your season pass?</label>
						                                            <div class="radio-list">
						                                                <input type="radio" name="season-pass" value="yes" />Yes<br />
						                                                <input type="radio" name="season-pass" value="no" />No<br />
						                                                <input type="radio" name="season-pass" value="season-pass" /> I don't have a season pass
						                                            </div>
						                                        </div>
						                                        <div class="radio-div-right">
						                                            <label>Would you like information on purchasing a season<br /> pass?</label>
						                                            <div class="radio-list">
						                                                <input type="radio" name="purchase" value="yes" />Yes<br />
						                                                <input type="radio" name="purchase" value="no" />No<br />
						                                            </div>
						                                        </div>
						                                        <div class="radio-div">
						                                            <label>Wheelchair Access &amp;<br /> seating required?</label>
						                                            <div class="radio-list">
						                                                <input type="radio" name="seating" value="yes" />Yes<br />
						                                                <input type="radio" name="seating" value="no" />No<br />
						                                            </div>
						                                        </div>
						                                        <div class="captcha<?php echo $posts->ID.$count?>">
							                                        <div class="captcha-code">
							                                             <span class="lbb captcha_code_i" oncontextmenu="return false" style='-moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;' 
	 unselectable='on' onselectstart='return false;' onmousedown='return false;'></span>
	 																	<input type="hidden" name="captcha_orig" id="captcha_orig" class="captcha_orig" />
							                                            <a href="#" class="captcha_refresh"><img src="<?php echo get_bloginfo("template_url")."/images/"; ?>captcha-refresh.gif" alt="" /></a>
							                                        </div>
						                                        </div>
						                                        <div class="captcha-text">
						                                            <label>Please enter the above text</label>
						                                            <input type="text" name="captcha-textfield" id="captcha-textfield" class="captcha-textfield"/>
						                                        </div>
						                                        <br style="clear:both;" />
						                                        <div class="errormsgdisp">** Please fill up the all fields.</div>
						                                        <div class="captchaerrormsg">** Please enter the correct captcha.</div>
						                                        <input type="submit" class="submit" name="submit" id="submit1" value="submit" />
						                                    </form>
						                                    </div>
						                                    <br style="clear:both" />
						                                    <ul class="nb">
						                                        <li>No payments required at this time. <span>All payments</span> are made at the Theater via Cash, Check or Money Order on the day of the performance.</li>
						                                        <li><span>RTC does not accept credit/debit cards, please plan accordingly.</span></li>
						                                        <li>All seats will be assigned on a "Best Available" basis by house management.</li>
						                                        <li>You will receive an automated email from <a href="mailto:reservations@rockawaytheatrecompany.org">reservations@rockawaytheatrecompany.org</a> with your reservation number and reservation information. Please present this at the Theater on the day of the performance.</li>
						
						                                   </ul>
						                                </div>
						                            </div>
					  					</div>
			  					<?php 
			  					$count++;
			  					$reservation_ticket_no++;
			  					update_option( 'reservation_no_generate', $reservation_ticket_no );
			  				}  
			  				if($statusofdate!="hasconcert")
			  				{
			  					change_post_status($posts->ID,'draft');
			  				}
			  				?>            	
	                    </div>
                    <div class="ticket-status-bottom"></div>
                    <?if($timeupmessage) echo $timeupmessage;?>
                    <div class="nb-section">
                    	**This program is supported in part by public funds from NYC Department of Cultural Afairs and Councilman Eric Ulrich**
                    </div>
                    
                </div>
                <div class="corner1"></div>
                <div class="corner2"></div>
                <div class="corner3"></div>
                <div class="corner4"></div>
            </div>
           <!--event end-->
<?php  }  ?>
            </div>
    </div>
    </div></div>
<?php get_footer(); ?>
