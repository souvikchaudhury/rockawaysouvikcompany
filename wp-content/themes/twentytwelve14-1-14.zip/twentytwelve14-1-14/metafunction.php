<?php
/******************************************************************************************************************
 * Rockaway Custom Meta Box 
 * Author Name: Souvik Chaudhury
 * Company Profile: http://capitalnumbers.com
 ******************************************************************************************************************/
		function event_info_function( $post )
		{
			wp_enqueue_script('media-upload');
			?>
			<script type="text/javascript" src="<?php echo get_bloginfo("template_url")."/js/"; ?>rockawaycustom.js"></script>
			 <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
				<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
			<style>
				#post-body #normal-sortables{ min-height:0px; }	
				.event_performance td ,.event_titling td{ border: 1px solid #D3D3D3;  padding: 5px;}
				.event_performance > table, .event_titling > table{ border: 1px solid #D3D3D3;}
				.performanceclose, .performanceadd, .eventtitlingadd, .eventtitlingclose{ cursor:pointer;}
			</style>
			<?php
				// Use nonce for verification
			    wp_nonce_field( plugin_basename( __FILE__ ), 'event_info' );
				/************************************
				    **** get Value from post meta ****
				************************************/
				$directed = get_post_meta( $post->ID, '_directed', true );
				$assdirected = get_post_meta( $post->ID, '_assdirected', true );
				$musicdirection = get_post_meta( $post->ID, '_musicdirection', true );
				$musicarrangement = get_post_meta( $post->ID, '_musicarrangement', true );
				$written = get_post_meta( $post->ID, '_written', true );
				$venue = get_post_meta( $post->ID, '_venue', true );
				$musicalinfo = get_post_meta( $post->ID, '_musicalinfo', true );
				$total_no_eventperformance = get_post_meta( $post->ID, '_total_no_eventperformance', true );
				$eventperformance_schedule = get_post_meta( $post->ID, '_eventperformance_schedule', true );
			?>
			<table>
			<tr>
			<td><h4>Directed By:</h4></td>
		  	<td><input type="text" name="directed" value="<?php echo esc_attr($directed); ?>"/></td>
			</tr>
			<tr>
			<td><h4>Assistant Directed By:</h4></td>
		  	<td><input type="text" name="assdirected" value="<?php echo esc_attr($assdirected); ?>"/></td>
			</tr>
			<tr>
			<td><h4>Musical Direction By: </h4></td>
		  	<td><input type="text" name="musicdirection" value="<?php echo esc_attr($musicdirection); ?>"/></td>
		  	</tr>
		  	<tr>
			<td><h4>Musical Arrangements By: </h4></td>
			<td><input type="text" name="musicarrangement" value="<?php echo esc_attr($musicarrangement); ?>"/></td>
			</tr>
			<tr>
			<td><h4>Written By: </h4></td>
			<td><input type="text" name="written" value="<?php echo esc_attr($written); ?>"/></td>
			</tr>
			<tr>
			<td><h4>Venue: </h4></td>
		  	<td><input type="text" name="venue" value="<?php echo esc_attr($venue); ?>"/></td>
		  	</tr>
		  	<tr>
		  	<td><h4>Choose Musical or Non-Musical: </h4></td>
		  	<td>
		  		<input type="radio" name="musicalinfo" value="Musical" <?php echo ($musicalinfo=='Musical'?'checked=true':''); ?>/>Musical
		  		
		  		<input type="radio" name="musicalinfo" value="Non-Musical" <?php echo ($musicalinfo=='Non-Musical'?'checked=true':''); ?>/>Non Musical
		  	</td>
		  	<td><input type="radio" name="musicalinfo" value="YPW" <?php echo ($musicalinfo=='YPW'?'checked=true':''); ?>/>Young Peoples Workshop</td>
			<td><input type="radio" name="musicalinfo" value="OTHER" <?php echo ($musicalinfo=='OTHER'?'checked=true':''); ?>/>Special/Other Performance</td>
		  	</tr>
		  	</table>
		  	<h2>Performance Schedule</h2>
		  	<input type="hidden" name="totaltr" id="totaltr" class="totaltr">
		  	<p>	
		  		<div class="event_performance">
		  			<table>
		  				<tr>
		  					<td><b>Date</b></td>
		  					<td><b>Time</b></td>
		  					<td><b>Seat Availability</b></td>
		  				</tr>
		  				<?php 
							if ($total_no_eventperformance <= 0)
							{			
						?>
		  				<tr>
		  					<td><input type="text" name="eventperformancedate[]" id="" class="selector" ></td>
		  					<td>
		  					Hr:
		  						<select name="eventperformancetimehr[]">
		  							<?php 
		  							for($hr=0;$hr<24;$hr++)
		  							{
		  								if($hr<10)
		  									echo "<option>".'0'.$hr."</option>";
		  								else
		  									echo "<option>".$hr."</option>";
		  							}
		  							?>
		  						</select>
		  					Min:
		  						<select name="eventperformancetimemin[]">
		  							<?php 
		  							for($mn=0;$mn<60;$mn++)
		  							{
		  								if($mn<10)
		  									echo "<option>".'0'.$mn."</option>";
		  								else
		  									echo "<option>".$mn."</option>";
		  							}
		  							?>
		  						</select>
		  					</td>
		  					<td>
		  					    <select name="seatavailability[]">
		  							<option name="Yes">Available</option>
		  							<option name="No">Not Available</option>
		  						</select>
		  					</td>
		  					<td class="performanceclose">close</td>
		  				</tr>
		  			<?php 
					} 
		  			else
		  			{
		  				$reason_contents = unserialize($eventperformance_schedule);
		  				$count=1;
		  				foreach ($reason_contents as $reason_content)
		  				{
		  					$eventperformancetime = $reason_content['eventperformancetime'];
		  					$eventperformancetimearr = explode(':', $eventperformancetime);
		  			?>
		  					<tr>
			  					<td>
			  						<input type="text" name="eventperformancedate[]" id="" class="selector" value="<?php echo $reason_content['eventperformancedate']; ?>">
			  					</td>
			  					<td>
			  					Hr:
			  						<select name="eventperformancetimehr[]">
			  							<?php 
			  							for($hr=0;$hr<24;$hr++)
			  							{
			  								if($hr<10)
			  								{
			  									?>
			  									<option value="<?php echo '0'.$hr; ?>" <?php echo ($eventperformancetimearr[0]=='0'.$hr?'selected=true':''); ?>><?php echo '0'.$hr; ?></option>
			  									<?php
			  								}
			  								else
			  								{
			  									?>
			  									<option value="<?php echo $hr; ?>" <?php echo ($eventperformancetimearr[0]==$hr?'selected=true':''); ?> ><?php echo $hr; ?></option>";
			  									<?php 
			  								}
			  							}
			  							?>
			  						</select>
			  					Min:
			  						<select name="eventperformancetimemin[]">
			  							<?php 
			  							for($mn=0;$mn<60;$mn++)
			  							{
			  								if($mn<10)
			  								{
			  									?>
			  									<option value="<?php echo '0'.$mn; ?>" <?php echo ($eventperformancetimearr[1]=='0'.$mn?'selected=true':''); ?>><?php echo '0'.$mn; ?></option>
			  									<?php
			  								}
			  								else
			  								{
			  									?>
			  									<option value="<?php echo $mn; ?>" <?php echo ($eventperformancetimearr[1]==$mn?'selected=true':''); ?> ><?php echo $mn; ?></option>";
			  									<?php 
			  								}
			  							}
			  							?>
			  						</select>
			  					</td>
			  					<td>
			  					    <select name="seatavailability[]">
			  							<option value="Yes" <?php echo ($reason_content['seatavailability']=='Yes'?'selected=true':''); ?>>Available</option>
			  							<option value="No" <?php echo ($reason_content['seatavailability']=='No'?'selected=true':''); ?>>Not Available</option>
			  						</select>
			  					</td>
			  					<td class="performanceclose">close</td>
		  				  </tr>
		  			<?php
							$count++;
						}
					}
					?>
		  			</table>
		  			<div class="performanceadd">Add</div>
		  		</div>
		  	</p>
			<?php
		}
		/* When the post is saved, saves our custom data */
		function eventinfo_save_postdata( $post_id ) 
		{
		
			  // First we need to check if the current user is authorised to do this action. 
			  if ( 'page' == $_REQUEST['post_type'] ) {
			    if ( ! current_user_can( 'edit_page', $post_id ) )
			        return;
			  } else {
			    if ( ! current_user_can( 'edit_post', $post_id ) )
			        return;
			  }
			
			  // Secondly we need to check if the user intended to change this value.
			  if ( ! isset( $_POST['event_info'] ) || ! wp_verify_nonce( $_POST['event_info'], plugin_basename( __FILE__ ) ) )
			      return;
			
			  // Thirdly we can save the value to the database
			
			  //if saving in a custom table, get post_ID
			  $post_ID = $_POST['post_ID'];
			  //sanitize user input
			  $directed = sanitize_text_field( $_POST['directed']);
			  $assdirected = sanitize_text_field( $_POST['assdirected']);
			  $musicdirection = sanitize_text_field($_POST['musicdirection']);
			  $musicarrangement = sanitize_text_field($_POST['musicarrangement']);
			  $written = sanitize_text_field($_POST['written']);
			  $venue = sanitize_text_field($_POST['venue']);
			  $musicalinfo = sanitize_text_field($_POST['musicalinfo']);
			  
			  $eventperformancedate = $_POST['eventperformancedate'];
			  $eventperformancetimehr = $_POST['eventperformancetimehr'];
			  $eventperformancetimemin = $_POST['eventperformancetimemin'];
			  $seatavailability = $_POST['seatavailability'];
			  
			  $total = $_POST['totaltr'];
			  
			  for ($i=0; $i < $total-1; $i++)
			  {
			  	$arr[$i]['eventperformancedate'] = $eventperformancedate[$i];
			  	$arr[$i]['eventperformancetime'] = $eventperformancetimehr[$i].':'.$eventperformancetimemin[$i].':00';
			  	$arr[$i]['seatavailability'] = $seatavailability[$i];
			  }
			  
			  $total_serialize_value = serialize($arr);
			  // Do something with $mydata 
			  // either using 
			  add_post_meta($post_ID, '_directed', $directed, true) or
			    update_post_meta($post_ID, '_directed', $directed);
				
			 add_post_meta($post_ID, '_assdirected', $assdirected, true) or
			    update_post_meta($post_ID, '_assdirected', $assdirected);
				
			  add_post_meta($post_ID, '_musicdirection', $musicdirection, true) or
			    update_post_meta($post_ID, '_musicdirection', $musicdirection);
			    
			  add_post_meta($post_ID, '_musicarrangement', $musicarrangement, true) or
			    update_post_meta($post_ID, '_musicarrangement', $musicarrangement);
			    
			  add_post_meta($post_ID, '_written', $written, true) or
			    update_post_meta($post_ID, '_written', $written);
			    
			  add_post_meta($post_ID, '_venue', $venue, true) or
			    update_post_meta($post_ID, '_venue', $venue);
			    
			  add_post_meta($post_ID, '_musicalinfo', $musicalinfo, true) or
			    update_post_meta($post_ID, '_musicalinfo', $musicalinfo);
			    
			  add_post_meta($post_ID, '_eventperformance_schedule', $total_serialize_value, true) or
			    update_post_meta($post_ID, '_eventperformance_schedule', $total_serialize_value);
			   
			  add_post_meta($post_ID, '_total_no_eventperformance', $total-1, true) or
			    update_post_meta($post_ID, '_total_no_eventperformance', $total-1);
			 // or a custom table (see Further Reading section below)
		}
?>