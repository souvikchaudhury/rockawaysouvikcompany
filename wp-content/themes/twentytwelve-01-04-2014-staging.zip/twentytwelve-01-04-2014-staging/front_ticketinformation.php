<link href='http://fonts.googleapis.com/css?family=Lato:900' rel='stylesheet' type='text/css' />
<link href='http://fonts.googleapis.com/css?family=Snowburst+One' rel='stylesheet' type='text/css'>

<!-- <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script> -->
<?php  ob_flush(); ?>
<input type="hidden" value="<?php echo get_bloginfo('template_directory').'/images/ajax_loader_red_48.gif'; ?>" id="loaderImg" />

<div class="ticktLstng">
	<div class="preload_home"><img src='<?php echo get_bloginfo('template_directory').'/images/ajax_loader_red_48.gif'; ?>' alt="" /></div>
</div>
<div style="display: none;">
  <div id="bookNoWd" class="popup" style="width:900px;height:500px;">
  	<!-- <div class="preload"><img src='<?php echo get_bloginfo('template_directory').'/images/ajax_loader_red_48.gif'; ?>' alt="" /></div> -->
  </div>
</div>