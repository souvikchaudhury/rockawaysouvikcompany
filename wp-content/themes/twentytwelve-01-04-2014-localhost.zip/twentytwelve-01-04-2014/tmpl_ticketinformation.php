<?php
/*
Template Name: Ticket Reservation
*/
ob_flush();
if(get_option('reservation_no_generate')==false)
{
	add_option( 'reservation_no_generate', '10000');
}
	
function set_html_content_type() {

	return 'text/html';
}
if(isset($_POST['submit']))
{
	$table = 'wp_ticketreservation';
	
	$part_number['adult']=($_POST['adult']!='' ? $_POST['adult'] : 0);
	$part_number['adult_price']=$_POST['adult_price'];
	$part_number['senior']=($_POST['senior']!='' ? $_POST['senior'] : 0);
	$part_number['senior_price']=$_POST['senior_price'];
	$part_number['child']=($_POST['child']!='' ? $_POST['child'] : 0);
	$part_number['child_price']=$_POST['children_price'];
	
	$arr['eventid']			      = $_POST['nwpostid'];
	$arr['eventtitle']		      = $_POST['nwposttitle'];
	$arr['eventdate']		      = $_POST['nwdate'];
	$arr['eventtime']			  = $_POST['nwtime'];
	$arr['firstname']			  = $_POST['firstname'];
	$arr['lastname']			  = $_POST['lastname'];
	$arr['email'] 				  = $_POST['email'];
	$arr['phone'] 			      = $_POST['phone'];
	$arr['total-ticket_no_text']  = $_POST['total-ticket_no_text'];
	$arr['total-ticket_cost_text']= $_POST['total-ticket_cost_text'];
	$arr['ticket_division']		  =	$part_number;
	$arr['season-pass']  		  = $_POST['season-pass'];
	$arr['purchase'] 			  = $_POST['purchase'];
	$arr['seating']  			  = $_POST['seating'];
	
	echo '<pre>';
	print_r($arr);
	echo '</pre>';
	$eventperformance_schedule = get_post_meta( $_POST['nwpostid'], '_eventperformance_schedule', true );
	$reason_contents = unserialize($eventperformance_schedule);

	foreach ($reason_contents as $reason_content) {
		if($reason_content['eventperformanceid'] == $_POST['evnprfnctid']){
			$curntevntdate = $reason_content['eventperformancedate'];
			$curntevnttime = $reason_content['eventperformancetime'];
			$seatavl = $reason_content['seatavailability'];
		}
	}

	$get_date_time_event = date("Y-m-d", strtotime($curntevntdate)).T.date("G:i:s", strtotime($curntevnttime));
	$seconds = strtotime($get_date_time_event) - time();
	$hours = $seconds / 60 /  60;

	if($seconds >= 0 && $hours > 24 && $seatavl == 'Yes') {

			$sql_query = "select * FROM ".$table." WHERE ticketregno='".$_POST['reservation_no']."'";
			$mysqlRes = mysql_query($sql_query);

			$valuearr = serialize($arr);
			$rev_date = date("Y-m-d H:i:s");	
			$data = array( 
							'ticketregno' => $_POST['reservation_no'], 
							'reservationinfo' => $valuearr,
							'reservationtime' => $rev_date 
						 );
			
			if(mysql_num_rows($mysqlRes) > 0) {
							$headers_cancel  = "MIME-Version: 1.0\n";
							$headers_cancel .= "Content-type: text/html; charset=iso-8859-1\n";
							$headers_cancel .= "X-Priority: 3\n";
							$headers_cancel .= "X-MSMail-Priority: Normal\n";
							$headers_cancel .= "X-Mailer: php\n";
							$headers_cancel .= "From: \"". "Rockaway Theatre Company" ."\" <".get_option( 'ticketemailid',true).">\n";
							
							$msg_cancel= '<table><tr><td colspan="3" height="42"><b>Your Ticket Reservation not successfully done , please try again</b></td></tr></table>';

							wp_mail($_POST['email'], 'Ticket Reservation Cancel', stripslashes($msg_cancel), $headers_cancel);
		
			}
			else{
				
			$wpdb->insert( $table, $data);

			$to = get_option( 'ticketemailid',true);
			//$from = '[your-name] <[your-email]>';
			$subject = 'Ticket Reservation Information';
			$subject1 = $_POST['nwposttitle'].':Ticket Reservation';
			//$headers = 'From: '.$_POST['firstname'].'<'.$_POST['email'].'>' . "\r\n";
			$headers = 'From: Rockaway Theatre Company <'.$_POST['email'].'>' . "\r\n";
			$headers1 = 'From: Rockaway Theatre Company <'.$to.'>'. "\r\n";
			
			$message = '<table width="100%" border="0" cellspacing="0" cellpadding="0">
						  <tr>
						    <td width="20%">Show Name</td>
						    <td width="5%">:</td>
						    <td>'.$_POST['nwposttitle'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">Date</td>
						    <td width="5%">:</td>
						    <td>'.$_POST['nwdate'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">Time</td>
						    <td width="5%">:</td>
						    <td>'.$_POST['nwtime'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">Registration No</td>
						    <td width="5%">:</td>
						    <td>'.$_POST['reservation_no'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">Name</td>
						    <td width="5%">:</td>
						    <td>'.$_POST['firstname'].' '.$_POST['lastname'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">Email</td>
						    <td width="5%">:</td>
						    <td>'.$_POST['email'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">Phone</td>
						    <td width="5%">:</td>
						    <td>'.$_POST['phone'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">No. of Tickets</td>
						    <td width="5%">:</td>
						    <td>Adult- '.$part_number['adult'].', child- '.$part_number['child'].', senior- '.$part_number['senior'].'</td>
						  </tr>
						  <tr>
						    <td width="20%">Total Costs</td>
						    <td width="5%">:</td>
						    <td>$'.$_POST['total-ticket_cost_text'].'</td>
						  </tr>
						</table>';

			$message1 = '<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td>
								<img src="'.get_template_directory_uri().'/images/logo.png" alt="" width="147" height="128" />
							</td>
						</tr>
						<tr>
						<td>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
							  <tr>
							    <td width="20%">Show Name</td>
							    <td width="5%">:</td>
							    <td>'.$_POST['nwposttitle'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">Date</td>
							    <td width="5%">:</td>
							    <td>'.$_POST['nwdate'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">Time</td>
							    <td width="5%">:</td>
							    <td>'.$_POST['nwtime'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">Registration No</td>
							    <td width="5%">:</td>
							    <td>'.$_POST['reservation_no'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">Name</td>
							    <td width="5%">:</td>
							    <td>'.$_POST['firstname'].' '.$_POST['lastname'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">Email</td>
							    <td width="5%">:</td>
							    <td>'.$_POST['email'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">Phone</td>
							    <td width="5%">:</td>
							    <td>'.$_POST['phone'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">No. of Tickets</td>
							    <td width="5%">:</td>
							    <td>Adult- '.$part_number['adult'].', child- '.$part_number['child'].', senior- '.$part_number['senior'].'</td>
							  </tr>
							  <tr>
							    <td width="20%">Total Costs</td>
							    <td width="5%">:</td>
							    <td>$'.$_POST['total-ticket_cost_text'].'</td>
							  </tr>
							</table>
							</td>
							</tr></table>';
			
			add_filter( 'wp_mail_content_type', 'set_html_content_type' );
			wp_mail( $to, $subject, $message,$headers );
			wp_mail( $_POST['email'], $subject1, $message1,$headers1 );
			remove_filter( 'wp_mail_content_type', 'set_html_content_type' );
		}
	}else{

							$headers_cancel  = "MIME-Version: 1.0\n";
							$headers_cancel .= "Content-type: text/html; charset=iso-8859-1\n";
							$headers_cancel .= "X-Priority: 3\n";
							$headers_cancel .= "X-MSMail-Priority: Normal\n";
							$headers_cancel .= "X-Mailer: php\n";
							$headers_cancel .= "From: \"". "Rockaway Theatre Company" ."\" <".get_option( 'ticketemailid',true).">\n";
							
							$msg_cancel= '<table><tr><td colspan="3" height="42"><b>Your Ticket Reservation not successfully done , please try again</b></td></tr></table>';

							wp_mail($_POST['email'], 'Ticket Reservation Cancel', stripslashes($msg_cancel), $headers_cancel);



	}	
}
?>
<?php get_header(); ?>

<div class="ticktLstng"></div>
<div style="display: none;">
	<div id="bookNoWd" class="popup" style="width:900px;height:500px;"></div>
</div>
<?php get_footer(); ?>
